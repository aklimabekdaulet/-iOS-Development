//
//  ShoppingCartAssignment_playgroundApp.swift
//  ShoppingCartAssignment.playground
//
//  Created by Аклима Бекдаулет on 06.10.2025.
//

import SwiftUI

@main
struct ShoppingCartAssignment_playgroundApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
