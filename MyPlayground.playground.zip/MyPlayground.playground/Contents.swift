import Foundation

// MARK: - Part 1: Product Models

struct Product {
    let id: String
    let name: String
    let price: Double
    let category: Category
    let description: String

    enum Category: String {
        case electronics, clothing, food, books
    }

    var displayPrice: String {
        String(format: "$%.2f", price)
    }

    init?(id: String = UUID().uuidString,
          name: String,
          price: Double,
          category: Category,
          description: String) {
        guard price > 0 else { return nil }
        self.id = id
        self.name = name
        self.price = price
        self.category = category
        self.description = description
    }
}

struct CartItem {
    var product: Product
    private(set) var quantity: Int

    var subtotal: Double {
        product.price * Double(quantity)
    }

    mutating func updateQuantity(_ newQuantity: Int) {
        guard newQuantity > 0 else { return }
        quantity = newQuantity
    }

    mutating func increaseQuantity(by amount: Int) {
        guard amount > 0 else { return }
        quantity += amount
    }
}

// MARK: - Part 2: ShoppingCart

class ShoppingCart {
    private(set) var items: [CartItem] = []
    var discountCode: String?

    func addItem(product: Product, quantity: Int = 1) {
        guard quantity > 0 else { return }
        if let index = items.firstIndex(where: { $0.product.id == product.id }) {
            items[index].increaseQuantity(by: quantity)
        } else {
            items.append(CartItem(product: product, quantity: quantity))
        }
    }

    func removeItem(productId: String) {
        items.removeAll { $0.product.id == productId }
    }

    func updateItemQuantity(productId: String, quantity: Int) {
        if quantity == 0 {
            removeItem(productId: productId)
        } else if let index = items.firstIndex(where: { $0.product.id == productId }) {
            items[index].updateQuantity(quantity)
        }
    }

    func clearCart() { items.removeAll() }

    var subtotal: Double { items.reduce(0) { $0 + $1.subtotal } }

    var discountAmount: Double {
        guard let code = discountCode else { return 0 }
        switch code.uppercased() {
        case "SAVE10": return subtotal * 0.10
        case "SAVE20": return subtotal * 0.20
        default: return 0
        }
    }

    var total: Double { subtotal - discountAmount }
    var itemCount: Int { items.reduce(0) { $0 + $1.quantity } }
    var isEmpty: Bool { items.isEmpty }
}

// MARK: - Part 3: Order & Address

struct Address {
    let street: String
    let city: String
    let zipCode: String
    let country: String

    var formattedAddress: String {
        "\(street)\n\(city), \(zipCode)\n\(country)"
    }
}

struct Order {
    let orderId: String
    let items: [CartItem]
    let subtotal: Double
    let discountAmount: Double
    let total: Double
    let timestamp: Date
    let shippingAddress: Address

    init(from cart: ShoppingCart, shippingAddress: Address) {
        self.orderId = UUID().uuidString
        self.items = cart.items
        self.subtotal = cart.subtotal
        self.discountAmount = cart.discountAmount
        self.total = cart.total
        self.timestamp = Date()
        self.shippingAddress = shippingAddress
    }

    var itemCount: Int {
        items.reduce(0) { $0 + $1.quantity }
    }
}

// MARK: - Bonus: User

class User {
    let userId: String
    let name: String
    let email: String
    private(set) var orderHistory: [Order] = []

    init(name: String, email: String) {
        self.userId = UUID().uuidString
        self.name = name
        self.email = email
    }

    func placeOrder(_ order: Order) {
        orderHistory.append(order)
    }

    var totalSpent: Double {
        orderHistory.reduce(0) { $0 + $1.total }
    }
}

enum DiscountType {
    case percentage(Double)
    case fixedAmount(Double)
    case buyXGetY(buy: Int, get: Int)
}

extension ShoppingCart {
    func applyDiscount(_ discount: DiscountType) -> Double {
        switch discount {
        case .percentage(let percent):
            return subtotal * (1 - percent / 100)
        case .fixedAmount(let amount):
            return max(0, subtotal - amount)
        case .buyXGetY(let buy, let get):
            let totalItems = itemCount
            let freeItems = totalItems / (buy + get)
            let freeValue = (items.first?.product.price ?? 0) * Double(freeItems)
            return subtotal - freeValue
        }
    }
}
// MARK: - Part 4: Testing & Demonstrations (10 points)

func main() {
    print("\n🧪 TEST SCENARIOS")

    // 1. Create sample products
    guard let laptop = Product(name: "MacBook Pro", price: 1999.99, category: .electronics, description: "Powerful laptop for professionals!"),
          let book = Product(name: "Swift Programming", price: 29.99, category: .books, description: "Learn Swift effectively!"),
          let headphones = Product(name: "AirPods Pro", price: 249.99, category: .electronics, description: "Noise-cancelling earbuds!") else {
        print("❌ Failed to initialize sample products")
        return
    }

    // 2. Test adding items to cart
    let cart = ShoppingCart()
    cart.addItem(product: laptop, quantity: 1)
    cart.addItem(product: book, quantity: 2)

    // 3. Add same product again (update quantity)
    cart.addItem(product: laptop, quantity: 1)
    print("🛒 Laptop quantity updated, total items: \(cart.itemCount)")

    // 4. Cart calculations
    print("💰 Subtotal: \(cart.subtotal)")
    print("📦 Item count: \(cart.itemCount)")

    // 5. Test discount code
    cart.discountCode = "SAVE10"
    print("💳 Total with discount: \(cart.total)")

    // 6. Remove item
    cart.removeItem(productId: book.id)
    print("🗑️ After removing book, item count: \(cart.itemCount)")

    // 7. Demonstrate REFERENCE TYPE behavior
    func modifyCart(_ cart: ShoppingCart) {
        cart.addItem(product: headphones, quantity: 1)
    }
    modifyCart(cart)
    print("🎯 After modifyCart(), total items: \(cart.itemCount) (cart modified ✅)")

    // 8. Demonstrate VALUE TYPE behavior
    let item1 = CartItem(product: laptop, quantity: 1)
    var item2 = item1
    item2.updateQuantity(5)
    print("🧩 item1 quantity = \(item1.quantity), item2 quantity = \(item2.quantity)")
    print("✅ Value type confirmed (item1 unaffected)")

    // 9. Create order
    let address = Address(street: "123 Apple St", city: "Cupertino", zipCode: "95014", country: "USA")
    let order = Order(from: cart, shippingAddress: address)

    // 10. Modify cart after order creation
    cart.clearCart()
    print("📦 Order items count: \(order.itemCount)")
    print("🛒 Cart items count after clear: \(cart.itemCount)")

    // Bonus: Create user and order history
    let user = User(name: "Aklima", email: "aklima@example.com")
    user.placeOrder(order)
    print("👩‍💼 User total spent: \(user.totalSpent)")
    print("📜 Orders in history: \(user.orderHistory.count)")

    // Bonus: Test advanced discount
    let discountTotal = cart.applyDiscount(.percentage(20))
    print("🎁 Discounted total (20%): \(discountTotal)")

    print("\n✅ All tests executed successfully!")
}

// ✅ Run tests
main()

